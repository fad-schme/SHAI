# harness/integrations/anthropic_sdk.py — canonical hand-rolled async reference.
#
# RESPONSIBILITY
#   Async helper for agent code using the Anthropic SDK directly.
#   The canonical reference — read this before designing other integrations.
#
# WHAT TO IMPLEMENT
#   async def gated_dispatch(
#       tool_name: str,
#       tool_args: dict,
#       ctx: RuntimeContext,
#       *,
#       harness: Harness,
#       dispatch: Callable[[str, dict], Awaitable[Any]],
#   ) -> Any | GateDecision:
#       1. gate = await harness.check_tool_call(tool_name, tool_args, ctx)
#       2. If not gate.allowed: return gate
#       3. Return await dispatch(tool_name, gate.redacted_args or tool_args)
#
#   async def run_turn(
#       user_text: str,
#       ctx: RuntimeContext,
#       *,
#       harness: Harness,
#       llm_loop: Callable,
#   ) -> str:
#       """Wraps a full turn with load_sources + scan_input + loop +
#       scan_output + unload_sources. Shows the canonical turn structure.
#       See examples/hand_rolled_loop.py for full usage."""
#       tools = await harness.load_sources(ctx)
#       verdict = await harness.scan_input(user_text, ctx)
#       if verdict.blocked:
#           await harness.unload_sources(ctx)
#           return "[blocked]"
#       try:
#           result = await llm_loop(user_text, tools, ctx)
#           out_verdict = await harness.scan_output(result, ctx)
#           return out_verdict.redacted_text or result
#       finally:
#           await harness.unload_sources(ctx)
#
#   Subagent handoff (called by this integration when agent spawns a subagent):
#       child_ctx = harness.scope_context_for_subagent(ctx, sub_agent_id="research_sub")
#       # then run the child agent with child_ctx
#
# DO NOT
#   - Import anthropic.* unconditionally.
#   - Add LLM-calling logic inside gated_dispatch.
