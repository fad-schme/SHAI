# harness/integrations/pydantic_ai.py — async pydantic_ai integration.
#
# RESPONSIBILITY
#   Wire harness.check_tool_call into pydantic_ai's tool interception hook.
#   Call harness.scope_context_for_subagent() at the framework's
#   subagent handoff point — not by agent code manually.
#   See integrations/anthropic_sdk.py for the canonical pattern.
#
# WHAT TO IMPLEMENT
#   Follow the same async pattern as anthropic_sdk.py:
#     1. Intercept the framework's tool call at its hook point.
#     2. await harness.check_tool_call(name, args, ctx)
#     3. On deny: surface deny_reason via the framework's refusal mechanism.
#     4. On allow: dispatch with gate.redacted_args or original args.
#
#   For subagent handoff:
#     child_ctx = harness.scope_context_for_subagent(ctx, sub_agent_id=...)
#     Wire child_ctx into the spawned subagent's calls.
#
#   Framework SDK imported lazily — module importable without framework.
#
# DO NOT
#   - Add sync variants.
#   - Push scan_input/scan_output into the framework graph/loop.
#     Those remain the agent's responsibility.
#   - Expose new public types.
