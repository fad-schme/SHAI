# harness/integrations/__init__.py
#
# Async framework wiring helpers. Each module wires check_tool_call
# into the framework's tool interception hook. All integrations also
# call scope_context_for_subagent() at the framework's subagent
# handoff point — the agent developer does not call it manually.
#
# Six integrations:
#   anthropic_sdk.py   — gated_dispatch for hand-rolled async loops
#                        (canonical reference; read this first)
#   langgraph.py       — HarnessGate async node
#   langchain.py       — async wrap_tool() returning a gated BaseTool
#   crewai.py          — async wrap_tool() intercepting Tool._run
#   pydantic_ai.py     — async wrap_tool() for @agent.tool pattern
#   openai_agents.py   — async harness_hook() for before_tool_call
#
# CONVENTION
#   - Framework SDK imported lazily inside wrapper. Module importable
#     without framework installed.
#   - All wrappers are async.
#   - scope_context_for_subagent() called by the integration at the
#     framework's subagent handoff point — NOT by agent code.
#   - No new public types. Wire types: Tool, RuntimeContext, GateDecision.
