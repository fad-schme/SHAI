# harness/audit/emitter.py — async AuditEmitter.
#
# RESPONSIBILITY
#   Receive one AuditEvent from a boundary and ship it to every
#   configured AuditSink. Single point of fan-out. Always on.
#
# WHAT TO IMPLEMENT
#   - AuditEmitter class:
#       __init__(self, sinks: list[AuditSink])
#
#       async emit(self, event: AuditEvent) -> None:
#           For each sink, call await sink.emit(event).
#           Wrap each in try/except. Log failures with canonical fields
#           (adapter=sink.name, boundary=event.boundary,
#           agent_id=event.agent_id, sub_agent_id=event.sub_agent_id,
#           op="audit_emit").
#           If ALL sinks raise: raise AuditEmissionError with all sink
#           names in context.
#           Run sinks concurrently via asyncio.gather(return_exceptions=True).
#
#       async close(self) -> None:
#           Call await sink.close() on every sink, swallow per-sink errors.
#
# INVARIANTS
#   - emit() calls every sink even after one fails.
#   - The AuditEvent is already redacted before reaching the emitter.
#   - Sinks run concurrently — order of emission not guaranteed.
#     If ordering matters, a sink must handle it internally.
#
# DO NOT
#   - Add filtering or sampling. Fan-out only.
#   - Add sync emit() variant.
#   - Re-export sinks.
