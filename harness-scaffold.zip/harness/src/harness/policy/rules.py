# harness/policy/rules.py — reference rule-based PolicyEngine.
#
# RESPONSIBILITY
#   Reference async PolicyEngine using YAML-declared rules. Implements
#   both evaluate() (intersection model) and evaluate_source().
#
# WHAT TO IMPLEMENT
#   - RuleBasedPolicy implementing PolicyEngine Protocol:
#       name = "rules"
#
#       Constructor: path to rules YAML or in-memory list. Validates at
#       construction; ConfigError on invalid structure. Not reloaded at
#       runtime.
#
#   async evaluate(tool, args, ctx, *, rules=None) -> PolicyDecision:
#       Intersection model:
#         Pass 1: if rules provided (combined subagent + parent rules),
#                 evaluate in declaration order. First match → return.
#         Pass 2: evaluate engine's loaded global rules in declaration
#                 order. First match → return.
#         No match → PolicyDecision(action="allow").
#       First deny in either pass wins immediately.
#
#   async evaluate_source(source, ctx) -> SourceDecision:
#       Evaluate source-activation rules from loaded rule set.
#       Match on source.tags and ctx fields (agent_id, sub_agent_id).
#       Default: SourceDecision(active=True).
#
#   Rule grammar (see docs/policy.md):
#       match:
#         tool_tags:    list[str]   (any-intersection)
#         tool_names:   list[str]
#         transport:    list[str]   (local | mcp | skill)
#         agent_ids:    list[str]
#         sub_agent_ids: list[str]  (match on sub_agent_id)
#         source_tags:  list[str]   (evaluate_source only)
#         any / all / not: nested combinators
#       action: allow | deny | redact | suppress
#       reason: str                 (required for deny)
#       redact: dict                (complete arg replacement for redact)
#       id:     str                 (stable rule id)
#
# DO NOT
#   - Add CEL, regex, or expression languages. That is OPA/Cedar.
#   - Reload rules at runtime.
#   - Add sync evaluate() variant.
