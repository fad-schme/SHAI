# harness/policy/engine.py — the PolicyEngine Protocol.
#
# RESPONSIBILITY
#   The single Protocol every policy engine implements. All methods async.
#
# WHAT TO IMPLEMENT
#   - SourceDecision: frozen dataclass:
#       active: bool
#       reason: str | None
#
#   - PolicyEngine as a typing.Protocol:
#
#       name: str
#
#       async def evaluate(
#           self,
#           tool: Tool,
#           args: dict[str, Any],
#           ctx: RuntimeContext,
#           *,
#           rules: list[RuleConfig] | None = None,
#       ) -> PolicyDecision:
#           """Intersection model:
#           1. If rules provided (subagent + parent agent rules combined):
#              evaluate in order. First match → decision.
#           2. If no match in provided rules, evaluate engine's global rules.
#              First match → decision.
#           3. No match anywhere → PolicyDecision(action="allow").
#
#           First deny anywhere wins. Restriction flows downward only.
#           Raises PolicyEvaluationError ONLY on engine failure (bad bundle,
#           network error). A normal deny is a PolicyDecision, not an
#           exception.
#           """
#
#       async def evaluate_source(
#           self,
#           source: ToolSource,
#           ctx: RuntimeContext,
#       ) -> SourceDecision:
#           """Decide whether source is active for this turn.
#           Uses ctx.agent_id and ctx.sub_agent_id to determine profile.
#           Default: SourceDecision(active=True).
#           """
#
# DO NOT
#   - Add sync variants.
#   - Add reload() or compile().
#   - Pass AuditEmitter — audit is the boundary's job.
#   - Add SandboxPolicy — removed. Use tool tags.
