# harness/boundaries/scan_output.py — the scan_output boundary.
#
# RESPONSIBILITY
#   Run configured output scanners over LLM output text, aggregate
#   findings, emit exactly one audit event, return ScanVerdict. Async.
#
# WHAT TO IMPLEMENT
#   Same shape as scan_input.run with:
#     - boundary name = "output_scan"
#     - uses the output scanner set
#
#   If the implementation is structurally identical to scan_input.run
#   apart from the boundary name string and scanner set, extract a
#   private helper in boundaries/__init__.py and delegate from both.
#   Do not duplicate. See CLAUDE.md §5.
#
# DO NOT
#   - Add re-entry into the LLM.
#   - Couple directly to scan_input.py. Share via the helper only.
