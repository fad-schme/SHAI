# harness/boundaries/scan_input.py — the scan_input boundary.
#
# RESPONSIBILITY
#   Run configured input scanners over user-provided text, aggregate
#   findings, emit exactly one audit event, return ScanVerdict. Async.
#
# WHAT TO IMPLEMENT
#   async def run(
#       text: str,
#       ctx: RuntimeContext,
#       *,
#       scanners: list[Scanner],
#       emitter: AuditEmitter,
#       enabled: bool,
#       block_at: Severity = Severity.high,
#   ) -> ScanVerdict
#
#   Algorithm:
#     1. Start timer.
#     2. If not enabled:
#          Emit AuditEvent(boundary="input_scan", decision="allow",
#          disabled=True, finding_count=0, ...).
#          Return ScanVerdict(blocked=False, findings=[], redacted_text=None).
#     3. Run each scanner concurrently (asyncio.gather, return_exceptions=True).
#        Scanner exceptions are logged with full context and treated as
#        empty findings — the pipeline continues.
#     4. blocked = any(f.severity >= block_at for f in findings).
#     5. redacted_text = last scanner's redacted output or None.
#     6. Emit one AuditEvent with agent_id, sub_agent_id, findings summary.
#     7. Return ScanVerdict.
#
# INVARIANTS
#   - Exactly one AuditEvent per call, every path.
#   - AuditEvent populated from ctx.to_log_fields() — never hand-build
#     the identity fields.
#   - No raw text in the audit event.
#   - Scanners run concurrently via asyncio.gather.
#
# DO NOT
#   - Make decisions beyond "block at severity threshold".
#   - Mutate input text.
#   - Call any LLM, retrieval, or memory code.
