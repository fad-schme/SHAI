# harness/adapters/scanners/regex_pii.py — reference async PII scanner.
#
# RESPONSIBILITY
#   Detect common PII patterns using regex. Async method that returns
#   immediately (no I/O). Ships with core.
#
# WHAT TO IMPLEMENT
#   - RegexPIIScanner implementing Scanner Protocol:
#       name = "regex_pii"
#       Constructor: optional list of enabled categories (default all).
#
#       Categories: email (medium), phone (medium), ssn (high),
#                   credit_card (high), ipv4 (low), api_key_like (medium).
#
#       async scan(text, ctx) -> ScanResult:
#           Run compiled regex patterns. Return findings with category,
#           severity, span. redacted_text with matches replaced by
#           "[REDACTED:<category>]". Never include raw match in detail.
#           Returns immediately — no await needed internally, just
#           `async def` for Protocol compliance.
#
# DO NOT
#   - Add ML-based detection.
#   - Put matched text in Finding.detail.
#
# ENTRY POINT: harness.scanners / "regex_pii"
