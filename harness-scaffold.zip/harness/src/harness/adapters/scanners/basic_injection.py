# harness/adapters/scanners/basic_injection.py — reference async injection scanner.
#
# RESPONSIBILITY
#   Detect common prompt-injection patterns using a curated pattern set.
#   Async method that returns immediately (no I/O). Ships with core.
#
# WHAT TO IMPLEMENT
#   - BasicInjectionScanner implementing Scanner Protocol:
#       name = "basic_injection"
#       Constructor: optional sensitivity (low|medium|high, default medium).
#
#       Categories: instruction_override (high), role_hijack (high),
#                   exfil_request (medium), tool_coercion (medium),
#                   delimiter_smuggling (low, high sensitivity only).
#
#       async scan(text, ctx) -> ScanResult:
#           Run pattern set for configured sensitivity.
#           redacted_text: None — injection detection does not auto-rewrite.
#           Returns immediately — async def for Protocol compliance only.
#
# ENTRY POINT: harness.scanners / "basic_injection"
