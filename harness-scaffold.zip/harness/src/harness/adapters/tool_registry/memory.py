# harness/adapters/tool_registry/memory.py — in-process tool registry.
#
# RESPONSIBILITY
#   Reference ToolRegistry + ScopedRegistryView backed by plain dicts.
#
# WHAT TO IMPLEMENT
#   - InMemoryRegistry implementing ToolRegistry Protocol:
#       name = "memory"
#       Internal: dict[str, Tool], threading.Lock (writes only)
#
#       async register(tool): identical tool → no-op; conflict → ConfigError.
#       async register_many(tools): loops register().
#       async get(name) -> Tool: lock-free read; ToolNotRegisteredError on miss.
#       async list() -> list[Tool]: insertion order.
#       async scoped_view(ctx) -> InMemoryRegistryView: fresh empty overlay.
#
#   - InMemoryRegistryView implementing ScopedRegistryView:
#       Constructor: (base: InMemoryRegistry, ctx: RuntimeContext)
#       Internal: dict[str, Tool] (per-turn overlay)
#
#       async add(tool): write to overlay only. Never touches shared base.
#       async get(name): overlay first, then base.get(name).
#       async list(): base.list() + overlay values, overlay wins on conflict.
#
#   View keying is NOT the registry's concern — keying happens in
#   Harness._views. The registry just creates views on demand.
#
# CONCURRENCY
#   async get/list on base: lock-free (GIL in CPython).
#   async register/register_many: acquire threading.Lock.
#   InMemoryRegistryView: single-agent single-turn — no locking needed.
#
# DO NOT
#   - Store views on the registry.
#   - Key views on user_id or session_id.
#   - Persist to disk.
#
# ENTRY POINT: harness.tool_registry / "memory"
