# harness/adapters/tool_sources/local.py — local tool source.
#
# RESPONSIBILITY
#   Surfaces statically registered local tools through the source
#   activation model. Returns immediately — no network, no credentials.
#
# WHAT TO IMPLEMENT
#   - LocalSource implementing ToolSource Protocol:
#       name = "local"
#       transport = Transport.local
#       tags = configurable
#
#       Constructor: reference to shared ToolRegistry base.
#
#       async load(ctx) -> list[Tool]:
#           Return tools from shared base whose tags intersect with
#           ctx.allowed_tags (if set). Returns immediately.
#           ctx.user_id and ctx.session_id ignored.
#
# ENTRY POINT: harness.tool_sources / "local"
