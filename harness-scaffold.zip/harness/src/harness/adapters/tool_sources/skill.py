# harness/adapters/tool_sources/skill.py — skill tool source.
#
# RESPONSIBILITY
#   Activates a named group of local tools on demand (progressive disclosure).
#
# WHAT TO IMPLEMENT
#   - SkillSource implementing ToolSource Protocol:
#       name = "skill"
#       transport = Transport.skill
#       tags = configurable
#
#       Constructor: skill_name, tool_names: list[str], registry: ToolRegistry.
#       Validates tool_names exist at construction — ConfigError on miss.
#
#       async load(ctx) -> list[Tool]:
#           Look up each tool_name in registry base.
#           Return found tools. Returns immediately.
#           ctx.user_id and ctx.session_id ignored.
#
# ENTRY POINT: harness.tool_sources / "skill"
