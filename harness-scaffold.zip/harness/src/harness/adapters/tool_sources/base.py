# harness/adapters/tool_sources/base.py — ToolSource Protocol and SourceRegistry.
#
# RESPONSIBILITY
#   Two things that belong together:
#   1. ToolSource Protocol — what every source adapter implements.
#   2. SourceRegistry — activates sources per turn per agent/subagent.
#      Implementation of Harness.load_sources().
#
# TOOLSOURCE PROTOCOL (all async)
#
#   class ToolSource(Protocol):
#       name:      str
#       transport: Transport   (local | mcp | skill)
#       tags:      list[str]
#
#       async def load(self, ctx: RuntimeContext) -> list[Tool]:
#           """Load tools for this agent/subagent turn.
#           Credential-free — credentials injected at construction time.
#           ctx.agent_id and ctx.sub_agent_id identify the caller.
#           ctx.user_id and ctx.session_id are ignored — not relevant to
#           which tools a source provides.
#           Must be safe for concurrent async calls.
#           """
#
# SOURCE REGISTRY
#
#   class SourceRegistry:
#       Constructor: list[ToolSource], PolicyEngine, ToolRegistry.
#
#       async activate(ctx, agent_profile) -> list[Tool]:
#           1. For each source name in agent_profile.sources,
#              resolve the ToolSource by name.
#           2. For each resolved source, call:
#              await policy.evaluate_source(source, ctx).
#              Suppressed sources are skipped.
#           3. For active sources: tools = await source.load(ctx).
#              Run loads concurrently via asyncio.gather.
#           4. Add loaded tools to ScopedRegistryView (passed in from
#              Harness.load_sources — not created here).
#           5. Return flat list of all active tools.
#
#       SourceRegistry never creates or stores views. View lifecycle is
#       owned by Harness._views.
#
# DO NOT
#   - Store views on SourceRegistry.
#   - Key anything on user_id or session_id.
#   - Resolve credentials in load() — construction-time only.
#   - Add sync load() variant.
