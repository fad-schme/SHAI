# harness/adapters/secrets/env.py — reference SecretsProvider.
#
# RESPONSIBILITY
#   Resolve secret://NAME by reading os.environ[NAME]. Called only at
#   Harness.from_yaml() time — not in the hot path. Sync is fine since
#   this runs once at startup before the async event loop handles turns.
#
# WHAT TO IMPLEMENT
#   - EnvSecrets:
#       name = "env"
#       Constructor: optional prefix str.
#
#       resolve(ref) -> str:  [SYNC — startup only]
#           Validate "secret://" prefix.
#           Strip prefix, prepend optional namespace.
#           os.environ lookup. Missing or empty → ConfigError naming
#           the variable (not the value).
#           Return value.
#
#   Note: SecretsProvider.resolve() is sync despite the rest of the
#   stack being async. Secret resolution happens once at startup during
#   from_yaml() before any async boundary calls. Making it async would
#   add unnecessary complexity. Document this exception.
#
# DO NOT
#   - Log resolved values. Ever.
#   - Fall back to .env files.
#
# ENTRY POINT: harness.secrets / "env"
