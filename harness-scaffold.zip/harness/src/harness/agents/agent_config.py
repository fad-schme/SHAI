# harness/agents/agent_config.py — AgentConfig and SubAgentConfig schemas.
#
# RESPONSIBILITY
#   Pydantic models that validate agent-xx.yaml files. Both AgentConfig
#   and SubAgentConfig are part of the public API. Source of truth for
#   what a valid agent definition looks like.
#
# WHAT TO IMPLEMENT
#   - SubAgentConfig (frozen pydantic, extra="forbid"):
#       id:                   str           (snake_case, unique within parent)
#       allowed_tool_names:   list[str]     (required, non-empty; hard gate —
#                                            must be ⊆ parent allowed_tool_names;
#                                            validated at AgentConfig load time)
#       allowed_tags:         list[str]     (required, non-empty; must be ⊆
#                                            parent allowed_tags; validated at
#                                            AgentConfig load time)
#       sources:              list[str]     (source names from harness.yaml;
#                                            independent — NOT required to be
#                                            ⊆ parent sources)
#       policy_rules:         list[RuleConfig] = []
#
#   - AgentConfig (frozen pydantic, extra="forbid"):
#       id:                   str           (required, snake_case [a-z][a-z0-9_]*)
#       display_name:         str | None
#       version:              str | None    (semver, informational)
#
#       allowed_tool_names:   list[str]     (required, non-empty — hard gate;
#                                            principle of least privilege)
#       allowed_tags:         list[str]     (required, non-empty)
#       sources:              list[str]     (source names from harness.yaml)
#       policy_rules:         list[RuleConfig] = []
#       sub_agents:           list[SubAgentConfig] = []
#
#       log_level:            str = "INFO"  (DEBUG|INFO|WARNING|ERROR)
#       audit_tags:           dict[str, str] = {}
#
#   - RuleConfig: reuse the same model from policy/rules.py. Do not
#     duplicate the schema.
#
#   - AgentConfig.get_sub_agent(sub_agent_id) -> SubAgentConfig:
#       Return the SubAgentConfig for sub_agent_id.
#       Raises SubAgentNotDeclaredError if not found.
#       Called by Harness.scope_context_for_subagent().
#
#   - Cross-field validators on AgentConfig:
#       - allowed_tool_names non-empty
#       - allowed_tags non-empty
#       - sub_agent ids unique within parent
#       - for each SubAgentConfig:
#           sub.allowed_tool_names ⊆ parent.allowed_tool_names
#           sub.allowed_tags ⊆ parent.allowed_tags
#         (Both validated at load time, not at runtime. ConfigError on
#          violation — the agent file is wrong, not the caller.)
#
#   - id format validator: [a-z][a-z0-9_]* (snake_case, no spaces)
#   - log_level validator: one of DEBUG|INFO|WARNING|ERROR
#
# DO NOT
#   - Add executor, LLM client, or loop configuration.
#   - Require SubAgentConfig.sources ⊆ parent.sources — subagent sources
#     are independent. allowed_tags is the enforcement mechanism.
#   - Make AgentConfig or SubAgentConfig mutable.
