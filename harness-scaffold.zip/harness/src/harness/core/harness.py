# harness/core/harness.py — the Harness facade.
#
# RESPONSIBILITY
#   The ONLY public entry point of the SDK. Holds adapter instances,
#   AgentRegistry, and the internal WeakValueDictionary of
#   ScopedRegistryViews. Delegates everything to internal modules.
#   No business logic here.
#
# WHAT TO IMPLEMENT
#   - Harness class. All methods async def except scope_context_for_subagent.
#
#   - Harness.from_yaml(path) -> Harness  [classmethod, sync]:
#       1. config.loader.load_yaml(path) → HarnessConfig
#       2. Resolve adapters via adapters.discovery.resolve(group, name)
#       3. Instantiate adapters with resolved secrets where needed
#       4. Construct AuditEmitter with resolved sinks
#       5. Construct AgentRegistry
#       6. Initialise self._views = WeakValueDictionary()
#       7. Return Harness
#
#   AGENT MANAGEMENT (operator-driven, explicit):
#
#   async load_agent(path) -> AgentConfig
#   async reload_agent(path) -> AgentConfig
#   async deregister_agent(agent_id) -> None
#   async list_agents() -> list[AgentConfig]
#       All delegate to AgentRegistry.
#
#   STARTUP:
#
#   async register_tools(tools) -> None
#       Delegate to ToolRegistry. Startup only.
#
#   PER-TURN:
#
#   async load_sources(ctx) -> list[Tool]:
#       1. key = ctx.agent_key()   # (agent_id, sub_agent_id or "")
#       2. Resolve active agent/subagent profile from AgentRegistry
#       3. Get active sources for this profile
#       4. Create ScopedRegistryView via tool_registry.scoped_view(ctx)
#       5. For each active source: await source.load(ctx), add to view
#       6. Store view in self._views[key]
#       7. Return list of active tools
#
#   async unload_sources(ctx) -> None:
#       key = ctx.agent_key()
#       Drop self._views[key]. No audit event.
#       If key not in _views: no-op (idempotent).
#
#   async scan_input(text, ctx) -> ScanVerdict:
#       Delegate to boundaries.scan_input.run(...)
#
#   async check_tool_call(name, args, ctx) -> GateDecision:
#       registry_view = self._views.get(ctx.agent_key())
#       Delegate to boundaries.check_tool_call.run(
#           ..., registry_view=registry_view or self._tool_registry)
#
#   async scan_output(text, ctx) -> ScanVerdict:
#       Delegate to boundaries.scan_output.run(...)
#
#   SUBAGENT (sync, pure — called by framework integrations):
#
#   scope_context_for_subagent(ctx, sub_agent_id) -> RuntimeContext:
#       1. agent_config = self._agent_registry.get(ctx.agent_id)
#          (sync get — registry reads are GIL-safe)
#       2. sub_config = agent_config.get_sub_agent(sub_agent_id)
#          Raises SubAgentNotDeclaredError if not found.
#       3. Return RuntimeContext(
#              tenant_id=ctx.tenant_id,
#              agent_id=ctx.agent_id,       # parent identity preserved
#              sub_agent_id=sub_agent_id,
#              allowed_tags=sub_config.allowed_tags,
#              user_id=ctx.user_id,         # inherited for audit
#              session_id=ctx.session_id,   # inherited for audit
#          )
#
# INTERNAL STATE
#   _views: WeakValueDictionary[tuple[str,str], ScopedRegistryView]
#       Keyed on ctx.agent_key() = (agent_id, sub_agent_id or "").
#       WeakValueDictionary provides GC safety net if unload_sources
#       is not called. Explicit unload_sources is still required.
#
# DO NOT
#   - Store per-turn state other than _views.
#   - Key _views on user_id, session_id, or request_id.
#   - Put boundary logic here.
#   - Expose adapter instances on the public surface.
