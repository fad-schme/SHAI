# harness/core/errors.py — exception hierarchy.
#
# RESPONSIBILITY
#   HarnessError and subclasses. Every harness exception derives from
#   HarnessError so callers can catch the whole library with one clause.
#
# WHAT TO IMPLEMENT
#   - HarnessError(Exception): base. Constructor accepts message plus
#     optional structured fields: tenant_id, agent_id, sub_agent_id,
#     adapter, boundary, op. Structured fields are EXPOSED as attributes
#     for log formatters — not just in the message string.
#
#   - Subclasses:
#       ConfigError(HarnessError)
#           Invalid harness.yaml or agent-xx.yaml content.
#
#       AdapterDiscoveryError(HarnessError)
#           Adapter name in config cannot be resolved to an entry point.
#
#       AdapterInitError(HarnessError)
#           Adapter constructor failed.
#
#       AgentNotRegisteredError(HarnessError)
#           agent_id not in AgentRegistry. check_tool_call maps to deny.
#
#       AgentConflictError(HarnessError)
#           load_agent called for an agent_id already registered with
#           different content. Caller must use reload_agent explicitly.
#
#       SubAgentNotDeclaredError(HarnessError)
#           sub_agent_id not declared under the calling agent_id in
#           AgentConfig.sub_agents. Raised by scope_context_for_subagent.
#
#       ToolNotRegisteredError(HarnessError)
#           Registry lookup miss. Maps to deny in check_tool_call.
#
#       PolicyEvaluationError(HarnessError)
#           Policy engine failed to evaluate (bad bundle, network).
#           A normal deny is PolicyDecision, not an exception.
#
#       AuditEmissionError(HarnessError)
#           ALL configured sinks failed. Single sink failure is logged
#           and swallowed; total failure surfaces here.
#
# DO NOT
#   - Add ScanBlockedError — blocking is a ScanVerdict, not an exception.
#   - Allow exceptions without context fields when those fields exist.
