# tests/integration/test_concurrent_agents.py
#
# RESPONSIBILITY
#   Verify N concurrent agents (top-level and subagent) share one Harness
#   instance safely. No cross-agent tool leakage.
#
# WHAT TO TEST (all async)
#
#   - 10 concurrent top-level agents, different agent_ids:
#       Each runs a full turn concurrently via asyncio.gather.
#       All succeed. No AuditEvent carries a wrong agent_id.
#
#   - 10 concurrent subagents under the same parent (agent_id same,
#     sub_agent_id same, different user_id for audit variety):
#       Each gets its own ScopedRegistryView.
#       No tool loaded by agent A appears in agent B's check_tool_call.
#
#   - Parent and subagent running concurrently:
#       Parent: orchestrator_agent, sub_agent_id=None.
#       Child: orchestrator_agent, sub_agent_id="research_sub".
#       Both run load_sources concurrently.
#       Parent's view contains outlook_mcp tools.
#       Child's view contains only docs_skill tools.
#       Views are isolated.
#
#   - unload_sources under concurrency:
#       10 agents load and unload in overlapping windows.
#       No KeyError, no stale view access.
