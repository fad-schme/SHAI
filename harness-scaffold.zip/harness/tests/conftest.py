# tests/conftest.py — shared async pytest fixtures.
#
# RESPONSIBILITY
#   Shared fixtures across the test suite.
#
# WHAT TO IMPLEMENT
#   - @pytest.fixture ctx() -> RuntimeContext
#       Returns stable test context:
#         tenant_id="t1", agent_id="orchestrator_agent",
#         sub_agent_id=None, user_id="u1", session_id="s1"
#       user_id and session_id present for audit trail testing only.
#
#   - @pytest.fixture sub_ctx(ctx) -> RuntimeContext
#       Returns a subagent context:
#         same tenant_id and agent_id as ctx
#         sub_agent_id="research_sub"
#         allowed_tags narrowed to ["read", "internal"]
#
#   - @pytest.fixture recording_sink() -> RecordingSink
#       Async AuditSink that appends events to self.events: list.
#       Tests assert on .events after boundary calls.
#
#   - @pytest.fixture async harness(tmp_path, recording_sink) -> Harness
#       Loads tests/fixtures/harness.yaml with recording_sink wired.
#       Loads tests/fixtures/agents/orchestrator_agent.yaml.
#
#   - pytest_configure: register asyncio mode = "auto" so all async
#     tests run without explicit @pytest.mark.asyncio.
#
# DO NOT
#   - Mock individual adapters suite-wide.
#   - Key fixtures on user_id or session_id for harness-internal purposes.
#   - Create fixtures only used in one test file here.
