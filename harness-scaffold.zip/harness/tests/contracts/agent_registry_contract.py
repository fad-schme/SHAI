# tests/contracts/agent_registry_contract.py — AgentRegistry conformance suite.
#
# WHAT TO IMPLEMENT
#   class AgentRegistryContract:
#       registry_factory: ClassVar[Callable[[], AgentRegistry]]
#       valid_agent_path:  ClassVar[Path]   # orchestrator_agent.yaml
#       alt_agent_path:    ClassVar[Path]   # same id, different content
#
#       async def test_load_registers_agent(self): ...
#       async def test_load_idempotent_on_identical_content(self): ...
#       async def test_load_raises_conflict_on_different_content(self): ...
#       async def test_reload_replaces_existing(self): ...
#       async def test_reload_raises_on_unknown_agent(self): ...
#       async def test_reload_keeps_old_on_invalid_file(self): ...
#       async def test_deregister_removes_agent(self): ...
#       async def test_deregister_raises_on_unknown(self): ...
#       async def test_get_returns_registered_agent(self): ...  # sync get
#       async def test_get_raises_on_unknown(self): ...
#       async def test_list_returns_all_registered(self): ...
#
#       async def test_subagent_declared(self):
#           """get() returns AgentConfig with sub_agents populated.
#           get_sub_agent("research_sub") returns SubAgentConfig.
#           get_sub_agent("unknown") raises SubAgentNotDeclaredError."""
#
#       async def test_concurrent_get_is_safe(self):
#           """50 concurrent calls to registry.get(). No exceptions."""
#           await self.registry.load(self.valid_agent_path)
#           results = await asyncio.gather(
#               *[asyncio.to_thread(self.registry.get, "orchestrator_agent")
#                 for _ in range(50)],
#               return_exceptions=True
#           )
#           assert not any(isinstance(r, Exception) for r in results)
