# tests/contracts/sink_contract.py — AuditSink conformance suite.
#
# RESPONSIBILITY
#   Every AuditSink adapter must pass this suite, wherever it lives.
#
# WHAT TO IMPLEMENT
#   class AuditSinkContract:
#       sink_factory: ClassVar[Callable[[], AuditSink]]
#
#       async def test_emit_accepts_real_audit_event(self): ...
#       async def test_name_is_stable(self): ...
#       async def test_close_is_idempotent(self): ...
#       async def test_emit_after_close_is_error_or_noop(self): ...
#
#       async def test_concurrent_emit(self):
#           """50 concurrent async emit() calls. No loss, no exceptions."""
#           sink = self.sink_factory()
#           events = [make_audit_event() for _ in range(50)]
#           results = await asyncio.gather(
#               *[sink.emit(e) for e in events],
#               return_exceptions=True
#           )
#           errors = [r for r in results if isinstance(r, Exception)]
#           assert not errors
#           # RecordingSink: assert len(sink.events) == 50
